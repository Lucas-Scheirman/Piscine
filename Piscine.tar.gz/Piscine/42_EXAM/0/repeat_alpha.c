#include <stdio.h>
#include <unistd.h>
void ft_repeat_alpha(int n,char *a)
{
    int i;
    i=0;
    int o;
    o=0;
    while (a[o])
    {
        while(i<n)
        {

            write(1,&a,1);
            write(1,"\n",1);
            i++;
        }
        
        o++;
    }
    
}


int main (int argc,char **argv)
{


    if (argc != 2 )
    {
        write(1,'\n',1);
    }
    else{
            ft_repeat_alpha(5,argv[1][0]);

    }
}
