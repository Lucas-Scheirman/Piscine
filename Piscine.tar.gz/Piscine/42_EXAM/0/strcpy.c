char    *ft_strcpy(char *s1, char *s2)


{

    int i;
    i=0;

    while(s2[i])

    {
        s1[i]=s2[i];

    }
    s1[i]=s2[i];
    return s1;
}





*/*La fonction strcpy() copie la chaîne pointée par src (y compris l'octet nul « \0 » final) dans la chaîne pointée par dest. Les deux chaînes ne doivent pas se chevaucher. La chaîne dest doit être assez grande pour accueillir la copie.

La fonction strncpy() est identique, sauf que seuls les n premiers octets de src sont copiés. Avertissement : s'il n'y a pas d'octet nul dans les n premiers octets de src, la chaîne résultante dans dest ne disposera pas d'octet nul final.

Dans le cas où la longueur de src est inférieure à n, la fin de dest sera remplie avec des octets nuls.

Une implémentation simple de strncpy() pourrait être : */