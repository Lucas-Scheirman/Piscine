/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lscheirm <lscheirm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/12 11:27:15 by lscheirm          #+#    #+#             */
/*   Updated: 2026/02/12 16:53:39 by lscheirm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strcmp(char *s1, char *s2)
{
	int	i;

	i = 0;
	while (s1[i] || s2[i])
	{
		if (s1[i] != s2[i])
			return (s1[i] - s2[i]);
		i++;
	}
	return (0);
}
/*
La fonction strcmp() compare les deux chaînes s1 et s2.
Elle renvoie un entier négatif, nul, ou positif, si s1 est respectivement
inférieure, égale ou supérieure à s2.

La fonction strncmp() est identique sauf qu'elle ne compare que les n (au plus)
premiers caractères de s1 et s2.

VALEUR RENVOYÉE
Les fonctions strcmp() et strncmp() renvoient un entier inférieur, égal ou
supérieur à zéro si s1 (ou ses n premiers octets) est respectivement
inférieure, égale ou supérieure à s2.
*/