/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lscheirm <lscheirm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/12 11:27:21 by lscheirm          #+#    #+#             */
/*   Updated: 2026/02/12 16:53:39 by lscheirm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	i;

	i = 0;
	if (n == 0)
		return (0);
	while (s1[i] && s2[i] && s1[i] == s2[i] && i < n)
		i++;
	if (i == n || i < 0)
		return (0);
	return (s1[i] - s2[i]);
}
/*
Cette fonction permet de comparer deux chaînes de caractères et de savoir si la
première est inférieure, égale ou supérieure à la seconde. Cette comparaison
sera faite dans l'ordre lexicographique (en tenant compte des valeurs ASCII des
caractères comparés). Néanmoins la comparaison se fera au maximum sur les n
premiers caractères.

En langage C, les chaînes de caractères sont qualifiées d'AZT : A Zéro Terminal.
Cela signifie qu'une chaîne de caractères se termine forcément par un code ASCII
nul (pouvant aussi être représenté par '\0').

Paramètres :
- first : la première chaîne de caractères à comparer.
- second : la seconde chaîne de caractères à comparer.
- length : le nombre maximal (un entier non signé) de caractères à comparer.

Valeur de retour :
Trois cas distincts doivent être considérés. Soit les deux chaînes sont égales :
dans ce cas, une valeur nulle sera retournée. Soit la première chaîne est plus
petite que la seconde (dans l'ordre lexicographique) : dans ce cas, une valeur
négative sera retournée. Soit la première chaîne est plus grande que la seconde :
dans ce dernier cas, une valeur positive sera renvoyée. Dans tous les cas, la
valeur absolue indiquera la position du premier caractère permettant de produire
le résultat.

Attention : la comparaison porte au maximum sur les n premiers caractères de la
chaîne.
*/