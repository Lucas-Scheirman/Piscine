/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lscheirm <lscheirm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/12 11:27:28 by lscheirm          #+#    #+#             */
/*   Updated: 2026/02/12 18:53:39 by lscheirm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcat(char *dest, char *src)
{
	int	i;
	int	o;

	i = 0;
	o = 0;

	while (dest[i])
		i++;
	while (src[o])
	{
		
		dest[i] = src[o];
		o++;

		i++;
	}
	dest[i] = '\0';
	return (dest);
}


#include <stdio.h>

int	main(void)
{
	char	a[30] = "fdgg";
	char	b[] = "dssdf";

	printf("%s", ft_strcat(a, b));
}
/*
La fonction strcat() ajoute la chaîne src à la fin de la chaîne dest en
écrasant le caractère nul ("\0") à la fin de dest, puis en ajoutant un nouveau
caractère nul final. Les chaînes ne doivent pas se chevaucher, et la chaîne dest
doit être assez grande pour accueillir le résultat. Les fonctions strcat() et
strncat() renvoient un pointeur sur la chaîne résultat dest.
*/
