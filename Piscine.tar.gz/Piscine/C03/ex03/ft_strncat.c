/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lscheirm <lscheirm@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/12 11:27:34 by lscheirm          #+#    #+#             */
/*   Updated: 2026/02/12 18:58:10 by lscheirm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	unsigned int	i;
	unsigned int	j;

	i = 0;
	j = 0;
	while (dest[i])
		i++;

	
	while (src[j] && j < nb)
	{
		dest[i] = src[j];
		j++;
		i++;
	}
	dest[i] = '\0';
	return (dest);
}
/*
#include <stdio.h>
int main()
{
	char dest[20] = "Hello, ";
	char src[] = "world!";
	unsigned int nb = 15;

	printf ("%s",ft_strncat(dest, src, nb));
	return (0);
}*/
/*
 * strncat() concatène au maximum n caractères de la chaîne src
 * à la fin de la chaîne dest.
 *
 * Contrairement à strcat(), elle ne copie que les n premiers
 * caractères de src.
 *
 * Si src contient n caractères ou plus, elle n'a pas besoin
 * d'être terminée par un caractère nul.
 *
 * La chaîne résultante dans dest est toujours terminée
 * par un caractère nul '\0'.
 *
 * Attention : si src contient au moins n caractères,
 * strncat() écrit n + 1 caractères dans dest
 * (n caractères copiés + le '\0' final).
 *
 * Il faut donc que dest ait une taille suffisante :
 * au minimum strlen(dest) + n + 1.
 */
