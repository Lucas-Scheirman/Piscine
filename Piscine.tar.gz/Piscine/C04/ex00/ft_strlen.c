
#include <stdio.h>

int ft_strlen(char *str)
{
    int i;

    i=0;
    while (str[i])
    {
        i++;
    }
    return i;

}
/*
int main()

{
    printf("%d",ft_strlen("fdgfddfg"));

}

renvoie le nombre de caractères dans une chaîne de caractères*/