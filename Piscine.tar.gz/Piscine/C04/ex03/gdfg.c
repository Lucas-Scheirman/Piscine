#include <unistd.h>
void sgdsf (int nb)

{

    char a;


    if (nb > 10)
    {
        sgdsf(nb /10) ;

        
    }
    
    a =   nb + '0';
    write(1,&a,1);
}

int main ()
{

    sgdsf(150);
}