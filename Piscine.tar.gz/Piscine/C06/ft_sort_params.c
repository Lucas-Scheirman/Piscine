#include <unistd.h>

int main(int argc,char **argv)

{
    int i=1;
    int tabTaille[argc - 1];

    if(argc > 1)
    {
    while(argv[i])
        {
            while[i]
            i++;
        }
    }
    

    /**/

}
/*Puisqu'il s'agit d'un programme, votre fichier .c doit contenir une fonction main.

• Écrivez un programme qui affiche ses arguments triés par ordre ASCII.

• Le programme doit afficher tous les arguments sauf argv[0].

• Chaque argument doit être affiché sur une nouvelle ligne.*/