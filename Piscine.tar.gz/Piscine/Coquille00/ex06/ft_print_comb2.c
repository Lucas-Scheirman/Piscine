/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: login <login@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/08 00:00:00 by login             #+#    #+#             */
/*   Updated: 2026/02/08 00:00:00 by login            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	writee(int i, int o);

#include <unistd.h>

void	ft_print_comb2(void)
{
	int		i;
	int		o;
	char	a;

	i = 0;
	o = 0;
	while (i <= 98)
	{
		
		
		while (o <= 99)
		{
			a = (i / 10) + '0';
			write(1, &a, 1);
			a = (i % 10) + '0';
			write(1, &a, 1);
			write(1, " ", 1);
			a = (o / 10) + '0';
			write(1, &a, 1);
			a = (o % 10) + '0';
			write(1, &a, 1);
			writee(i, o);
			o++;
		}
		o = 0;
		i++;

	}
}

void	writee(int i, int o)
{
	if (!(i == 98 && o == 99))
		write(1, ", ", 2);
}
